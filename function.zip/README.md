# LOL Cat Generator Lambda Function

This AWS Lambda function generates LOL cat memes with random funny phrases.

## Prerequisites

1. AWS CLI installed and configured
2. Node.js installed
3. An S3 bucket for storing generated images

## Setup

1. Install dependencies:
```bash
npm install
```

2. Create an S3 bucket and note its name

3. Deploy to AWS Lambda:
```bash
zip -r function.zip .
aws lambda create-function \
    --function-name lolcat-generator \
    --runtime nodejs18.x \
    --handler index.handler \
    --role YOUR_LAMBDA_ROLE_ARN \
    --zip-file fileb://function.zip
```

4. Set the environment variable in Lambda:
- S3_BUCKET: Your S3 bucket name

## Usage

The function will generate a random LOL cat meme and store it in the specified S3 bucket.
The response will include the URL to the generated image.
